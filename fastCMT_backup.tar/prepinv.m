function [G ista az_used]=prepinv(f,x,y,late,lone,ze)


%DMM 01/2011
%
%Kernel matrix for inversion
%
%IN
%
%f - GFs filename
%x - station coords, x~north
%y - station coords, y~east
%late - Latitude of epicentre
%lone - longitude of epicentre
%ze - depth of source
%
%OUT
%
%G - GFs matrix
%ista - index of stations in range



%Get GFs at station coordinates
[GZ1 GR1 GT1 GZ2 GR2 GT2 GZ3 GR3 GZ4 GR4 GT4 GZ5 GR5 GT5 ista] =makegreen(f,x,y,ze);
%[GZ1 GR1 GT1 GZ2 GR2 GT2 GZ3 GR3 GZ4 GR4 GT4 GZ5 GR5 GT5] = multimakegreen(f,x,y);

%Prepare inversion matrices

display('Preparing matrices for inversion...')
k=1;
for i=1:size(GR1,1)
    %Vertical component of Gram matrix
    G(k,1)=GZ1(i);
    G(k,2)=GZ2(i);
    G(k,3)=GZ3(i);
    G(k,4)=GZ4(i);
    G(k,5)=GZ5(i);
    %Radial component of Gram matrix
    G(k+1,1)=GR1(i);
    G(k+1,2)=GR2(i);
    G(k+1,3)=GR3(i);
    G(k+1,4)=GR4(i);
    G(k+1,5)=GR5(i);
    %Tangential component of Gram matrix
    G(k+2,1)=GT1(i);
    G(k+2,2)=GT2(i);
    G(k+2,3)=0;
    G(k+2,4)=GT4(i);
    G(k+2,5)=GT5(i);
        
    k=k+3;
end
a=0;

