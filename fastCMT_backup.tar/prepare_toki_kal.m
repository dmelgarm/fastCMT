function prepare_toki_kal

cd /diego-local/Research/Data/JapKal
load kdisp.mat
ma=35;
i=find(c.process==1);
T=c.t(i,:);
E=c.e(i,:);
N=c.n(i,:);
U=c.u(i,:);
i=find(T==0);
T(i)=NaN;
E(i)=NaN;
N(i)=NaN;
U(i)=NaN;
%Set up regular time intervals
maxt=max(max(T));
mint=min(min(T));
dt=0.01;
ma=ma/dt;
nsta=size(T,1);
ts=mint:dt:ceil(maxt);
%Output variables
Ts=repmat(ts,nsta,1);
Es=nan(size(Ts));
Ns=nan(size(Ts));
Us=nan(size(Ts));
%Read in stations
for k=1:nsta
    k
    i=~isnan(T(k,:));
    t=T(k,i);
    e=E(k,i);
    n=N(k,i);
    u=U(k,i);
    dt=t(2)-t(1);
    if dt < 0.009 %resample
        i=1:1:size(t,2);
        ni=floor(i(end)/2);
        i=2*i-1;
        i=i(1:ni);
        e=e(i);
        n=n(i);
        u=u(i);
        t=t(i);
    end
    lmint=t(1);
    lmaxt=t(end);
    i1=find(abs(ts-lmint)<dt/4);
    i2=find(abs(ts-lmaxt)<dt/4);
    e=movavg(e,ma,ma);
    n=movavg(n,ma,ma);
    u=movavg(u,ma,ma);
    Es(k,i1:i2)=e;
    Ns(k,i1:i2)=n;
    Us(k,i1:i2)=u;
end
cd /diego-local/Research/Data/GEONET/
E=Es;
N=Ns;
U=Us;
T=Ts;
save('tokikal.mat','E','N','U','T')