function plotverticals(N,E,U,T,epi)


late = epi(2);
lone = epi(1);
depth=epi(3);

%Get station info
% El Mayor
% cd /diego-local/Research/Events/GPS
% [n e dist]=get_init_pos('SEM_coseis_AZRYfix.txt',late,lone);

% Sendai
%cd /Users/dmelgarm/Desktop/Sendai
%[n e r]=get_init_pos('jpl_offsets.dat',late,lone);
%toki
cd /diego-local/Research//Data/GEONET/
[sta X Y Z a a a a a a]=textread('toki_init','%f%f%f%f%f%f%f%f%f%f');
[lat,lon,alt] = ecef2lla(X,Y,Z);
lat=rad2deg(lat);
lon=rad2deg(lon);
[dist,az] = distance(late,lone,lat,lon);
dist=deg2km(dist)*1000;
az=-az+90;
az=deg2rad(az);
[e n]=pol2cart(az,dist);
%

x=n;
y=e;
dsta=dist;
az=atan2(y,x);


%USE PRE_SAVED DATA
%cd /diego-local/Research/Events/GPS
%cd /Users/dmelgarm/Desktop/Sendai/
cd /diego-local/Research/Data/GEONET/
%load GFs.mat
%dsta=r;

%El Mayor
% dstadeg=km2deg(dsta/1000);
% [lat,lon] = reckon(late,lone,dstadeg,rad2deg(az));

%El Mayor
%load d_MA120.mat
% %load d.mat
%
%Sendai
%cd /Users/dmelgarm/Desktop/Sendai/
%load sendai_jpl.mat
%
%TOKI
%load toki.mat
N=N';
E=E';
U=U';
T=T'-T(1,1);

%stafil=[13 27 33 46 60 61 62 63 64 65 66 67 69 70 71 72 77 81];  %Stations i know have good looking offsets
%stafil=(1:1:1216);  %Sendai
stafil=(1:1:415); %TOKI
i=find(dsta<2000e3);   %Filter by desired range
stafil=find(ismember(i,stafil));   %Good offsets within those stations in range
%Synth
% stafil=1:1:Nsynth;
% dsta=r;
% %


%First extract data in range (counter i) then extract interesting stations
%(counter stafil)
nt=size(T,1);
az=az(i);
dsta=dsta(i);
lon=lon(i);
lat=lat(i);
x=x(i);
y=y(i);
T=T(:,i);
E=E(:,i);
N=N(:,i);
U=U(:,i);
az=az(stafil);
dsta=dsta(stafil);
lon=lon(stafil);
lat=lat(stafil);
x=x(stafil);
y=y(stafil);
T=T(:,stafil);
E=E(:,stafil);
N=N(:,stafil);
U=U(:,stafil);
%Toki
nsta=size(T,2);
nt=size(T,1);

%Not for Sendai
%mE=mean(E(1:500,:));
mE=mean(E(1:5,:));
mN=mean(N(1:5,:));
mU=mean(U(1:5,:));
mE=repmat(mE,nt,1);
mN=repmat(mN,nt,1);
mU=repmat(mU,nt,1);
E=E-mE;
N=N-mN;
U=(U-mU);
%Reduce times
%El Mayor
% ti=600:1:1100;
% T=T(600:1100,:);
% N=N(600:1100,:);
% E=E(600:1100,:);
% U=U(600:1100,:);
%Toki
ti=1:1:600;
T=T(ti,:);
N=N(ti,:);
E=E(ti,:);
U=U(ti,:);
%origin=660; %EQ origin time
origin=T(1,1);



plotsynth('toki1D',4)
title('\delta = 10\circ')
hold on
up=U(200,:)';
z=zeros(415,1);
i=find(up>0);
xplus=x(i)/1000;
yplus=y(i)/1000;
clear i
i=find(up<0);
upminus=up(i);
xminus=x(i)/1000;
yminus=y(i)/1000;
scatter(yminus,xminus,'o')
scatter(yplus,xplus,'x')
quiver(y/1000,x/1000,z,up,2)
colormap('bone')

