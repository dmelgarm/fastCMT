function M=multi2meca(m)

%DMM 04/2011
%
%Convert vecor with multiple point sources to momoent tensors

nsource=size(m,1)/5;
M=zeros(3,3);
i=1;
for k=1:nsource
    M(:,:,k)=mtinv2mt(m(i:i+4));
    i=i+5;
end