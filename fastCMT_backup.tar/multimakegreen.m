function [HZ1 HR1 HT1 HZ2 HR2 HT2 HZ3 HR3 HZ4 HR4 HT4 HZ5 HR5 HT5] = multimakegreen(f,XS,YS)

%DMM 01/2011
%
%Read GFs obtained through EGRNF and output GF values at station
%coordinates. EDGRN produces GFs at discrete radial distances from the 
%source, here we use spline interpolation to obtain the value of the GF at
%a given point and then weigh by the cos or sine of the azimuth. This last
%part is critical. For a source-stationn azimuth angle 'azi' from north one
%must compute the radial(r), transverse(t) and vertical (z) component of
%the Green function. Each station event pair has 5 GFs, ecah GF is mono
%valued and must be weighed as follows:
%
%G1=(G1z,G1r,G1t) is pure strike slip
%   Gz=G1z*sin(2*azi)
%   Gr=G1r*sin(2*azi)
%   Gt=G1t*cos(2*azi)
%
%G2=(G2z,G2r,G2t) is pure dip slip
%   Gz=G2z*cos(azi)
%   Gr=G2r*cos(azi)
%   Gt=G2t*sin(azi)
%
%G3=(G3z,G3r,0) is compensated linear vector dipole (CLVD) and is axis-symmetric
%   Gz=G3z
%   Gr=G3r
%   Gt=0
%
%G4=(G4z,G4r,G4t) is N45E strike slip
%   Gz=G4z*cos(2*azi)
%   Gr=G4r*cos(2*azi)
%   Gt=G4t*-sin(2*azi)
%
%G1=(G5z,G5r,G5t) is 45 degree dip dip-slip
%   Gz=G1*sin(azi)
%   Gr=G1*sin(azi)
%   Gt=G1*-cos(azi)



warning('off','all')
display('Inteprolating GFs...')
cd /Users/dmelgarm/Documents/scripts/Fortran/SyntheticGPS/grnfcts

%Read file from EDGRN
fid=fopen([f '.ss']);
%first 12 lines are headers, 13th line contains info on file structure,
%keep it!
for k=1:12
    fstruc=fgets(fid);
end
fstruc=str2num(fstruc);

%Get useful parameters
nr=fstruc(1);   %No. of radial distances
d1=fstruc(2);   %Start and stop radii
d2=fstruc(3);
fclose(fid);

%Get station azimuths and distances to origin
d=sqrt(XS.^2+YS.^2);
i=find(d<d2);  %Keep only stations in range
j=find(d>d2);
% d=d(i);
% XS=XS(i);
% YS=YS(i);
az=atan2(YS,XS);  %get azimuth
nsta=max([size(XS,1) size(XS,2)]);   %stations left
AZ=repmat(az,1,nr);   %For multiplying times GF matrix

%Get green functions
[Gss Gds Gcl]=rgreen(f);

%Cilindrical coordinates
r=linspace(d1,d2,nr);

%Extract GF informaiton from Gss, Gds and Gcl respectively then multiply
%each row (station) by trigonometric function fo each azimuth. Afterwards
%interpolate each row at the distance from orgiin to station.

%Strike slip (M1)
gz1=Gss(:,1)';
GZ1=repmat(gz1,[nsta,1]);
GZ1=GZ1.*sin(2*AZ);  %Adjust for azimuthal dependence
HZ1=spline(r,GZ1,d);
HZ1=diag(HZ1);
HZ1(j)=0;

gr1=Gss(:,2)';
GR1=repmat(gr1,[nsta,1]);
GR1=GR1.*sin(2*AZ);
HR1=spline(r,GR1,d);
HR1=diag(HR1);
HR1(j)=0;


gt1=Gss(:,3)';
GT1=repmat(gt1,[nsta,1]);
GT1=GT1.*cos(2*AZ);
HT1=spline(r,GT1,d);
HT1=diag(HT1);
HT1(j)=0;

%Dip slip (M2)
gz2=Gds(:,1)';
GZ2=repmat(gz2,[nsta,1]);
GZ2=GZ2.*cos(AZ);
HZ2=spline(r,GZ2,d);
HZ2=diag(HZ2);
HZ2(j)=0;

gr2=Gds(:,2)';
GR2=repmat(gr2,[nsta,1]);
GR2=GR2.*cos(AZ);
HR2=spline(r,GR2,d);
HR2=diag(HR2);
HR2(j)=0;

gt2=Gds(:,3)';
GT2=repmat(gt2,[nsta,1]);
GT2=GT2.*sin(AZ);
HT2=spline(r,GT2,d);
HT2=diag(HT2);
HT2(j)=0;

%CLVD (M3)
gz3=Gcl(:,1)';
GZ3=repmat(gz3,[nsta,1]);
HZ3=spline(r,GZ3,d);
HZ3=diag(HZ3);
HZ3(j)=0;

gr3=Gcl(:,2)';
GR3=repmat(gr3,[nsta,1]);
HR3=spline(r,GZ3,d);
HR3=diag(HR3);
HR3(j)=0;

%Strike slip (M4)
gz4=Gss(:,1)';
GZ4=repmat(gz4,[nsta,1]);
GZ4=GZ4.*cos(2*AZ);
HZ4=spline(r,GZ4,d);
HZ4=diag(HZ4);
HZ4(j)=0;

gr4=Gss(:,2)';
GR4=repmat(gr4,[nsta,1]);
GR4=GR4.*cos(2*AZ);
HR4=spline(r,GR4,d);
HR4=diag(HR4);
HR4(j)=0;

gt4=Gss(:,3)';
GT4=repmat(gt4,[nsta,1]);
GT4=GT4.*(-sin(2*AZ));
HT4=spline(r,GT4,d);
HT4=diag(HT4);
HT4(j)=0;

%Dip slip (M5)
gz5=Gds(:,1)';
GZ5=repmat(gz5,[nsta,1]);
GZ5=GZ5.*sin(AZ);
HZ5=spline(r,GZ5,d);
HZ5=diag(HZ5);
HZ5(j)=0;

gr5=Gds(:,2)';
GR5=repmat(gr5,[nsta,1]);
GR5=GR5.*sin(AZ);
HR5=spline(r,GR5,d);
HR5=diag(HR5);
HR5(j)=0;

gt5=Gds(:,3)';
GT5=repmat(gt5,[nsta,1]);
GT5=GT5.*(-cos(AZ));
HT5=spline(r,GT5,d);
HT5=diag(HT5);
HT5(j)=0;

display(['GFs interpolated up to threshold distance ' num2str(d2/1000) 'km'])



