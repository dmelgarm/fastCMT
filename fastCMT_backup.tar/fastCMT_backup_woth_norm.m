function [m L synthetics]=fastCMT(coseis,f,velmod,epi,psmecaf,normflag,weightflag,plotflag)

%DMM 01/2011
%
% Invert for moment tensor each time sample using GPS data. Inversion is
% performed using the coseismic offsets with a Green's function approach.
% Green's functions are obtained from EDCGRN numerical code (Wang et al.,
% 2002).
%
% Coordinate system throughout this code and the functions called within is
% (X,Y,Z)=(North,East,Down), this is important.
%
% Input variables:
%
% f - Green function file
% mu - Shear modulus at source depth
% epi - epicenter [lon lat depth(m)]
% psmecaf - psmeca filename
% normflag - 1 to normalize offsets 0 to leave absolute. Normalizing has
%            the effect of fitting the radiation pattern regardless of itsfranz ferd
%            amplitude. This seems to provide the best results.
% weightflag - Weight by preevent variances on all 3 channels.
% plotflag - Plot observed adovesnd synthetic offsets each time sample.
%
% Output variables:
%
% m - 3x3xNt array containing the moment tensor at each time step.
% L - 1xNt array containing misfits at each time step.





thresh=0.0  %Observation threshold

%Define coordinate origin
late = epi(2);
lone = epi(1);
depth= epi(3);
%Assign data
N=coseis.N';franz ferd
E=coseis.E';
U=-coseis.U';
T=coseis.T';
lat=coseis.lat;
lon=coseis.lon;
%Get station info
[dist,az] = distance(late,lone,lat,lon);
dist=deg2km(dist)*1000;
az=-az+90;
az=deg2rad(az);
[e n]=pol2cart(az,dist);
x=n;
y=e;
dsta=dist;
az=atan2(y,x);
%Dimensions of data
nt=size(T,1);
nsta=size(T,2);
ti=1:1:nt;
%Make Gram amtrix
G=prepinv(f,x,y,late,lone,depth); %El mayor


%Normalizedoves
S=eye(nsta*3);
% if normflag==1
%     S=sqrt(E(rc(1):rc(end),:).^2+N(rc(1):rc(end),:).^2+U(rc(1):rc(end),:).^2);
%     S=max(S);
%     S=repmat(S,nt,1);
%     ES=E./S;
%     NS=N./S;
%     US=U./S;
% end

%Obtain measurememnt errors from 500 seconds of pre-event data
%ystd=std(E(1:5,:));
%xstd=std(N(1:5,:));
%zstd=std(U(1:5,:))*5;

%Make indices to extract GFs from remaining stations
% i1=stafil*3-2;
% i2=stafil*3-1;
% i3=stafil*3;
% j1=interleave(i1,i2);
% j2=interleave(i2,i3);
% j=unique(interleave(j1,j2));
% G=G(j,:);  %Retain only remaining GFs


%Initalize stuff
m=zeros(3,3,nt); %Moment tensor
ds=zeros(size(nsta,1)*3,1); %Normalized data vector
synthetics=zeros(size(dsta,1),8);  %Synthetics stored here
s=1;  %Synthetics matrix counter


display('Inverting single CMT...')
mu=getmu(velmod,depth)
for k=1:nt
    k
    Tcurrent=T(k,:);
    i=find(~isnan(Tcurrent));
    Ecurrent=E(k,:);
    Ncurrent=N(k,:);
    Ucurrent=U(k,:);
    %Use only stations over threshold
    horiz=sqrt(Ecurrent.^2+Ncurrent.^2);
    i=find(horiz>=thresh);
    nsta=max([size(i,1) size(i,2)]);  %Stations in this epoch
    %Noise matrix
    W=eye(nsta*3);
    if nsta>2
        %Prepare data vector
        ds=zeros(nsta*3,1);
        dx=Ncurrent(i);
        dy=Ecurrent(i);      %Un-normalized for moment
        dz=Ucurrent(i);
        azi=az(i);
        d=ones(size(i,1)*3,1);
        iinv=1:1:nsta*3;
        iinv=reshape(iinv,3,nsta);
        %Indices for preparing d vector
        i1=iinv(1,:);
        i2=iinv(2,:);
        i3=iinv(3,:);
        %Extract only relevant rows of Gram matrix
        ii1=i*3-2;
        ii2=i*3-1;
        ii3=i*3;
        j1=interleave(ii1,ii2);
        j2=interleave(ii2,ii3);
        j=unique(interleave(j1,j2));
        Gj=G(j,:);
        if normflag==1  %Using normalized data
            %Alternate approach to normalizing
            S=sqrt(N(i).^2+E(i).^2+U(i).^2);
            dxs=N(i)./S;
            dys=E(i)./S;Tcurrent=T(k,:)
            dzs=-U(i)./S;doves
            %Alternate normalizing matrix
            Sn=1./S;
            Sn=interleave(Sn,Sn);
            Sn=interleave(Sn,Sn);
            is=(1:1:nsta)*4;
            Sn(is)=NaN;
            is=~isnan(Sn);
            Sn=Sn(is);
            Sn=diag(Sn);
            %
            %                 dxs=NS(i);
            %                 dys=ES(i);    %Normalized for geometry
            %                 dzs=-US(i);
            %Normalizing matrix
            %                 Sn=1./S(1,ihoriz);tic
            %                 Sn=interleave(Sn,Sn);
            %                 Sn=interleave(Sn,Sn);
            %                 is=(1:1:nsta)*4;
            %                 Sn(is)=NTcurrent=T(k,:)aN;
            %                 is=~isnan(Sn);
            %                 Sn=Sn(is);
            %                 Sn=diag(Sn);
            %Build normalized data vector
            ds(i1)=dzs;
            ds(i2)=dxs;
            ds(i3)=dys;
            Gjs=Sn*Gj;  %Weigh GFs by same factor as data
        else    %Nothig happens and normalized is absolute data vector
            ds(i1)=dz;
            ds(i2)=dx;
            ds(i3)=dy;
            Gjs=Gj;
        end
        %Always save un-normalized data
        d(i1)=dz;
        d(i2)=dx;
        d(i3)=dy;
        %Rotate un-normalized data to z,r,theta
        rot=buildrotmat(azi,2);
        dr=rot*d;
        %Rotate potentially normalized data to z,r,theta
        dsr=rot*ds;
        %Weight by standard errors
        if weightflag==1
            %Simplified weight scheme
            dw=zeros(1,nsta*3);
            dw(i1)=1/5;
            dw(i2)=1;
            dw(i3)=1;
            W=diag(dw);
            %                 W(i1,i1)=diag(1./zstd(ihoriz));
            %                 W(i2,i2)=diag(1./xstd(ihoriz));
            %                 W(i3,i3)=diag(1./ystd(ihoriz));
            is=isnan(W);
            W(is)=0;
            dsr=W*dsr;
            Gjs=W*Gjs;  %Weigh GFs by same factor as data
        end
        %Invert
        %             mt=lsqlin(Gjs,dsr);
        m0=ones(5,1)*1e17/mu;
        mt = l1decode_pd(m0, Gjs, [], dsr);
        L(k)=((Gjs*mt-dsr)'*(Gjs*mt-dsr))/(dsr'*dsr);
        %Synthetic mt
        %mt=[0.777 1.32 2.59;1.32 -0.411 -0.662;2.590 1.320 -0.366]*1e21/30e9;
        %mu=40e9;
        %mt=[1.82 1.34 3.17;1.34 -0.13 -0.56;3.17 -0.56 -1.69]*(1e22/mu);
        %             mt=[-0.249 -0.056 -0.014; -0.056 -0.594 -0.089;-0.014 -0.086 0.843]*(1e20)/mu;
        %             mt=mrp2mcart(mt);
        %             mt=mt2mtinv(mt);
        % _____
        %Now solve for moment if using normalized approach
        if normflag==1
            mt=mt/norm(mt);  %Normalize solution
            GM=Gj*mt;  %unormalized GFs with normalized CMT
            Mo=lsqlin(GM,dr);   %Solve for best fiting scalar momoent
            mt=mt*Mo;   %Scale CMT back to real size
            dsynth=Mo*GM;
            %Rotate back to z,x,y
            rot=buildrotmat(azi,1);
            dsynth=rot*dsdovesynth;
        end
        if weightflag==1
            %Rescale GFs and data
            ds=W\ds;
            Gjs=W\Gjs;
            dsynth=Gjs*mt;
            %Rotate back to z,x,y
            rot=buildrotmat(azi,1);
            dsynth=rot*dsynth;
        end
        if weightflag==0 & normflag==0
            dsynth=Gjs*mt;
            %Rotate back to z,x,y
            rot=buildrotmat(azi,1);
            dsynth=rot*dsynth;
        end
        %Misfit
        %L(k)=((Gjs*mt-dsr)'*(Gjs*mt-dsr))/(dsr'*dsr);%Misfit
        %             dx=d(i2)-dsynth(i2);
        %             dy=d(i3)-dsynth(i3);
        %             xrms=sqrt(sum(dx.^2)/nsta);
        %             yrms=sqrt(sum(dy.^2)/nsta);
        %             L(k)=sqrt(xrms^2+yrms^2);
        
        %             % synthetics %%% TESTING ONLY
        %             st=345;
        %             dip=45;
        %             rake=45;
        %             Mo=7.28e19/3.77e10;
        %             Ms=sdr2mom(st,dip,rake)*Mo;
        %             ms=mt2mtinv(Ms);
        %             dsynth=Gjs*ms;
        %             mt=lsqlin(Gjs,dsynth);
        %             rot=buildrotmat(azi,1);
        %             dsynth=rot*dsynth;
        %
        %
        %             %%%%%%%%%%%%%
        
        %Construct synthetics
        %1=station, 2=time, 3,4,5=observed data (Z,X,Y), 6,7,8=inverted%data
        Ns=s+nsta-1;
        synthetics(s:Ns,1)=i;
        synthetics(s:Ns,2)=ti(k);
        synthetics(s:Ns,3)=d(iinv(1,:));
        synthetics(s:Ns,4)=d(iinv(2,:));
        synthetics(s:Ns,5)=d(iinv(3,:));
        synthetics(s:Ns,6)=dsynth(iinv(1,:));
        synthetics(s:Ns,7)=dsynth(iinv(2,:));
        synthetics(s:Ns,8)=dsynth(iinv(3,:));
        synthetics(s:Ns,9)=lon(i);
        synthetics(s:Ns,10)=lat(i);
        %Scale momoent tensor by mu and write in cartesian form
        m(:,:,k)=mtinv2mt(mt*mu);
        M(k)=norm(m(:,:,k),'fro')/sqrt(2); %Scalar moment
        Mw(k)=0.67*(log10(M(k))-9.1); %Moment magnitude, 9.1 for Nm, 16.1 for dyn-cm
        s=Ns+1;  %Keep track of No of synthetics produced
    else %No synthetics
        L(k)=0;
        Mo(k)=0;
        Mw(k)=0;
        synthetics(s,2)=ti(k);
        s=s+1;
    end
end

if plotflag==1
    clear G N E U T
    %Make plots of syntehtics
    figure
    tplot=unique(synthetics(:,2));
    for k=1:size(tplot,1)
        
        [row col]=find(synthetics(:,2)==tplot(k));
        t(k)=tplot(k);
        if synthetics(row(1),1)>0
            ista=synthetics(row,1);
            
            dz=synthetics(row,3);
            dx=synthetics(row,4);
            dy=synthetics(row,5);
            sz=synthetics(row,6);
            sx=synthetics(row,7);
            sy=synthetics(row,8);
            
            
            %Get station coordinates
            xc=x(ista)/1000;
            yc=y(ista)/1000;
            
            %Plot, plot, plotaroo...
            scale=3;
            subplot(1,2,1)   %Horizontals
            quiver(yc,xc,dy,dx,scale)
            hold on
            quiver(yc,xc,sy,sx,scale)
            xlim([min(xc) max(xc)]);
            ylim([min(yc) max(yc)]);
            axis equal
            grid on
            xlabel('East (km)','FontSize',18)
            ylabel('North (km)','FontSize',18)
            title(['t = ' num2str(t(k))],'FontSize',18);
            legend('Observed','Synthetic')
            hold off
            subplot(1,2,2)   %verticals
            pq=zeros(size(xc));
            quiver(yc,xc,pq,dz,scale)
            hold on
            quiver(yc+5,xc,pq,sz,scale)
            xlim([min(xc) max(xc)]);
            ylim([min(yc) max(yc)]);
            axis equal
            grid on
            xlabel('East (km)','FontSize',18)
            ylabel('North (km)','FontSize',18)
            title(['t = ' num2str(t(k))],'FontSize',18);
            legend('Observed','Synthetic')
            hold off
            
            pause(0.01)
            
            
        else
            subplot(1,2,1)
            xlim([min(xc) max(xc)]);
            ylim([min(yc) max(yc)]);
            axis equal
            grid on
            xlabel('East (km)','FontSize',18)
            ylabel('North (km)','FontSize',18)
            title(['t = ' num2str(t(k))],'FontSize',18);
            subplot(1,2,2)
            xlim([min(xc)/1000 max(xc)/1000]);
            ylim([min(yc)/1000 max(yc)/1000]);
            axis equal
            grid on
            xlabel('East (km)','FontSize',18)
            ylabel('North (km)','FontSize',18)
            title(['t = ' num2str(t(k))],'FontSize',18);
            pause(0.01)
        end
    end    
end
%==========================================
