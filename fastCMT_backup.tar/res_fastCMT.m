function misfit=multifastCMT

%DMM 03/2011
%
%Test resolution of the fastCMT algorithm by intentionally placing the
%epicentre in the wrong location



%Input Parameters
fname='elmay'
mu=3.4e10;


%Define centre of grid
gc=[-115.39 32.31]; %This is the GCMT centroid
%Azimuth to orient grid
az=deg2rad(319);  %This is the usgs CMT nodal plane
%N-S and E-W spacing and No of grid points in each direction(m)
dns=10e3;
dew=10e3;
nx=4;
ny=8;
%Make grid
x=-dew*nx:dew:dew*nx;
y=-dns*ny:dns:dns*ny;
[X Y]=meshgrid(x,y);
nx=size(X,2);
ny=size(X,1);
%rotate grid
R=[sin(az) -cos(az);cos(az) sin(az)];
n=0;
for j=1:ny
    for k=1:nx
        n=n+1;
        G=[X(j,k); Y(j,k)];
        Gr=R*G;  %Rotated (x,y) coordinates of the node
        d=sqrt(Gr(1)^2+Gr(2)^2);   %Distance to irgini in (m)
        d=km2deg(d/1000);    %Distance in degs
        azir=atan2(X(j,k),Y(j,k));
        azir=az-azir;  %Reckoning angle is nodal plane angle - angle of grid point
        [lat(n) lon(n)]=reckon(gc(2),gc(1),d,rad2deg(azir));
    end
end


%Now feed data into fastCMT

N=nx*ny;
for k=1:N
    k
    psmecaf=['psmeca' num2str(k) '.inp']
    epi=[lon(k) lat(k)];
    [m L]=fastCMT(fname,mu,epi,psmecaf,1,0,0);
    misfit(k,:)=L;
end
misfit=misfit'
cd ~/Documents/scripts/GMT/fastCMT/
save('mecamisfit.dat','misfit','-ascii')
% fid = fopen('mecamisfit.dat', 'w');
% fprintf(fid, '%1.3f\n', misfit);
% fclose(fid);
%     

