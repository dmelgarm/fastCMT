function [m L]=fastCMT(f,mu,epi,psmecaf,normflag,weightflag,plotflag)

%DMM 01/2011
%
% Invert for moment tensor each time sample using GPS data. Inversion is
% performed using the coseismic offsets with a Green's function approach. 
% Green's functions are obtained from EDCGRN numerical code (Wang et al.,
% 2002).
% 
% Coordinate system throughout this code and the functions called within is
% (X,Y,Z)=(North,East,Down), this is important.
% 
% Input variables:
% 
% f - Green function file
% mu - Shear modulus at source depth
% epi - epicenter [lon lat]
% psmecaf - psmeca filename
% normflag - 1 to normalize offsets 0 to leave absolute. Normalizing has 
%            the effect of fitting the radiation pattern regardless of its 
%            amplitude. This seems to provide the best results.
% weightflag - Weight by preevent variances on all 3 channels.
% plotflag - Plot observed and synthetic offsets each time sample.
% 
% Output variables:
% 
% m - 3x3xNt array containing the moment tensor at each time step.
% L - 1xNt array containing misfits at each time step.



%Define epicentre or centroid
%Origin (GCMT seems to be the best)
late = epi(2);
lone = epi(1);
depth=28e3;

%Get station info
% El Mayor
% cd /diego-local/Research/Events/GPS
% [n e r]=get_init_pos('SEM_coseis_AZRYfix.txt',late,lone);
% Sendai
%cd /Users/dmelgarm/Desktop/Sendai
%[n e r]=get_init_pos('jpl_offsets.dat',late,lone);
%toki
cd /diego-local/Research//Data/GEONET/
[sta X Y Z a a a a a a]=textread('toki_init','%f%f%f%f%f%f%f%f%f%f');
[lat,lon,alt] = ecef2lla(X,Y,Z);
lat=rad2deg(lat);
lon=rad2deg(lon);
[dist,az] = distance(late,lone,lat,lon);
dist=deg2km(dist)*1000;
az=-az+90;
az=deg2rad(az);
[e n]=pol2cart(az,dist);
x=n;
y=e;

%USE PRE_SAVED DATA
%cd /diego-local/Research/Events/GPS
%cd /Users/dmelgarm/Desktop/Sendai/
cd /diego-local/Research/Data/GEONET/
%load GFs.mat
%dsta=r;
dsta=dist;
az=atan2(y,x);

%El Mayor
%load d_MA120.mat
% %load d.mat
%
%Sendai
%cd /Users/dmelgarm/Desktop/Sendai/
%load sendai_jpl.mat
%
%TOKI
load toki.mat
N=N';
E=E';
U=U';
T=T'-T(1,1);

%stafil=[13 27 33 46 60 61 62 63 64 65 66 67 69 70 71 72 77 81];  %Stations i know have good looking offsets
%stafil=(1:1:1216);  %Sendai
stafil=(1:1:415); %TOKI
i=find(dsta<1500e3);   %Filter by desired range
stafil=find(ismember(i,stafil));   %Good offsets within those stations in range
%Synth
% stafil=1:1:Nsynth;
% dsta=r;
% %


%First extract data in range (counter i) then extract interesting stations
%(counter stafil)
% T=T(:,i);
% nt=size(T,1);
% az=az(i);
% dsta=dsta(i);
% x=x(i);
% y=y(i);
% E=E(:,i);
% N=N(:,i);
% U=U(:,i);
% az=az(stafil);
% dsta=dsta(stafil);
% x=x(stafil);
% y=y(stafil);
% T=T(:,stafil);
% E=E(:,stafil);
% N=N(:,stafil);
% U=U(:,stafil);
% nsta=size(T,2);
%Toki
nsta=size(T,2);
nt=size(T,1);

%Not for Sendai
%mE=mean(E(1:500,:));
mE=mean(E(1:5,:));
mN=mean(N(1:5,:));
mU=mean(U(1:5,:));
mE=repmat(mE,nt,1);
mN=repmat(mN,nt,1);
mU=repmat(mU,nt,1);
E=E-mE;
N=N-mN;
U=(U-mU);
%Reduce times
ti=1:1:500;
%origin=660; %EQ origin time
origin=T(1,1)+23;
correction=0; %Correction for MA
nt=size(T,1);
[rc c]=find(T>=ti(1) & T<=ti(end));

%Make Gram amtrix
G=prepinv(f,x,y,late,lone,depth); %El mayor


% %synth
% ti=1;
% %


% %Filter
% fc=0.01;
% forder=4;
% N=fbutter(N,1,forder,fc,'low');
% E=fbutter(E,1,forder,fc,'low');
% U=fbutter(U,1,forder,fc,'low');
% %

%Normalize
S=eye(nsta*3);
if normflag==1
    S=sqrt(E(rc(1):rc(end),:).^2+N(rc(1):rc(end),:).^2+U(rc(1):rc(end),:).^2);
    S=max(S);
    S=repmat(S,nt,1);
    ES=E./S;
    NS=N./S;
    US=U./S;
end

%Obtain measurememnt errors from 500 seconds of pre-event data
ystd=std(E(1:5,:));
xstd=std(N(1:5,:));
zstd=std(U(1:5,:))*5;

%Make indices to extract GFs from remaining stations
% i1=stafil*3-2;
% i2=stafil*3-1;
% i3=stafil*3;
% j1=interleave(i1,i2);
% j2=interleave(i2,i3);
% j=unique(interleave(j1,j2));
% G=G(j,:);  %Retain only remaining GFs



%Iterate through epochs
nt=size(ti,2);
m=zeros(3,3,nt); %Moment tensor
ds=zeros(size(stafil,1)*3,1); %Normalized data vector
thresh=0.025;  %Observation threshold
synthetics=zeros(size(dsta,1),8);  %Synthetics stored here
s=1;  %Synthetics matrix counter


    %synth
%     for k=1
    
display('Inverting single CMT...')
    for k=2:size(ti,2)
    %for k=1
        Ecurrent=E(:,k);
        Ncurrent=E(:,k);
        Ucurrent=E(:,k);
        i=find(T==ti(k));
        %Use only stations over threshold
        horiz=sqrt(E(i).^2+N(i).^2);
        ihoriz=find(horiz>thresh);
        i=i(ihoriz);
        nsta=max([size(i,1) size(i,2)]);  %Stations in this epoch
        %Noise matrix
        W=eye(nsta*3);
        if nsta>2       
            %Prepare data vector
            ds=zeros(nsta*3,1);
            dx=N(i);
            dy=E(i);      %Un-normalized for moment
            dz=-U(i);     %Remember it is a RIGHT-HANDED system!
            azi=az(ihoriz);
            d=ones(size(i,1)*3,1);
            iinv=1:1:nsta*3;
            iinv=reshape(iinv,3,nsta);
            %Indices for preparing d vector
            i1=iinv(1,:);
            i2=iinv(2,:);
            i3=iinv(3,:);
            %Extract only relevant rows of Gram matrix
            ii1=ihoriz*3-2;
            ii2=ihoriz*3-1;
            ii3=ihoriz*3;
            j1=interleave(ii1,ii2);
            j2=interleave(ii2,ii3);
            j=unique(interleave(j1,j2));
            Gj=G(j,:);
            %Make rotation matrix (Cilindrical to local cartesian
            %rot=buildrotmat(azi,1);
            %Invert and stuff...
            %Gj=rot*Gj;
            if normflag==1  %Using normalized data
                %Alternate approach to normalizing
                S=sqrt(N(i).^2+E(i).^2+U(i).^2);
                dxs=N(i)./S;
                dys=E(i)./S;
                dzs=-U(i)./S;
                %Alternate normalizing matrix
                Sn=1./S;
                Sn=interleave(Sn,Sn);
                Sn=interleave(Sn,Sn);
                is=(1:1:nsta)*4;
                Sn(is)=NaN;
                is=~isnan(Sn);
                Sn=Sn(is);
                Sn=diag(Sn);
                %
%                 dxs=NS(i);
%                 dys=ES(i);    %Normalized for geometry
%                 dzs=-US(i);
                %Normalizing matrix
%                 Sn=1./S(1,ihoriz);
%                 Sn=interleave(Sn,Sn);
%                 Sn=interleave(Sn,Sn);
%                 is=(1:1:nsta)*4;
%                 Sn(is)=NaN;
%                 is=~isnan(Sn);
%                 Sn=Sn(is);
%                 Sn=diag(Sn);
                %Build normalized data vector
                ds(i1)=dzs;
                ds(i2)=dxs;
                ds(i3)=dys;
                Gjs=Sn*Gj;  %Weigh GFs by same factor as data
            else    %Nothig happens and normalized is absolute data vector
                ds(i1)=dz;
                ds(i2)=dx;
                ds(i3)=dy;
                Gjs=Gj;
            end
            %Always save un-normalized data
            d(i1)=dz;
            d(i2)=dx;
            d(i3)=dy;
            %Rotate un-normalized data to z,r,theta
            rot=buildrotmat(azi,2);
            dr=rot*d;
            %Weight by standard errors
            if weightflag==1
                %Simplified weight scheme
                dw=zeros(1,nsta*3);
                dw(i1)=1/3;
                dw(i2)=1;
                dw(i3)=1;
                W=diag(dw);
%                 W(i1,i1)=diag(1./zstd(ihoriz));
%                 W(i2,i2)=diag(1./xstd(ihoriz));
%                 W(i3,i3)=diag(1./ystd(ihoriz));
                is=isnan(W);
                W(is)=0;
                ds=W*ds;
                Gjs=W*Gjs;  %Weigh GFs by same factor as data
            end
            %Rotate potentially normalized data to z,r,theta
            rot=buildrotmat(azi,2);
            dsr=rot*ds;
            %Invert
            mt=lsqlin(Gjs,dsr);
            %Now solve for moment if using normalized approach
            if normflag==1
                mt=mt/norm(mt);  %Normalize solution
                GM=Gj*mt;  %unormalized GFs with normalized CMT
                Mo=lsqlin(GM,dr);   %Solve for best fiting scalar momoent
                mt=mt*Mo;   %Scale CMT back to real size
                dsynth=Mo*GM;
                %Rotate back to z,x,y
                rot=buildrotmat(azi,1);
                dsynth=rot*dsynth;
            end
            if weightflag==1
                %Rescale GFs and data
                ds=W\ds;
                Gjs=W\Gjs;
                dsynth=Gjs*mt;
                %Rotate back to z,x,y
                rot=buildrotmat(azi,1);
                dsynth=rot*dsynth;
            end
            if weightflag==0 & normflag==0
                dsynth=Gjs*mt;
                %Rotate back to z,x,y
                rot=buildrotmat(azi,1);
                dsynth=rot*dsynth;    
            end
            
            
%             % synthetics %%% TESTING ONLY
%             st=345;
%             dip=45; 
%             rake=45;
%             Mo=7.28e19/3.77e10;
%             Ms=sdr2mom(st,dip,rake)*Mo;
%             ms=mt2mtinv(Ms);
%             dsynth=Gjs*ms;
%             mt=lsqlin(Gjs,dsynth);
%             rot=buildrotmat(azi,1);
%             dsynth=rot*dsynth;
%             
%             
%             %%%%%%%%%%%%%
            
            %Construct synthetics
            %1=station, 2=time, 3,4,5=observed data (Z,X,Y), 6,7,8=inverted%data 
            Ns=s+nsta-1;
            synthetics(s:Ns,1)=ihoriz;
            synthetics(s:Ns,2)=ti(k);
            synthetics(s:Ns,3)=d(iinv(1,:));
            synthetics(s:Ns,4)=d(iinv(2,:));
            synthetics(s:Ns,5)=d(iinv(3,:));
            synthetics(s:Ns,6)=dsynth(iinv(1,:));
            synthetics(s:Ns,7)=dsynth(iinv(2,:));
            synthetics(s:Ns,8)=dsynth(iinv(3,:));
            %Scale momoent tensor by mu and write in cartesian form
            m(:,:,k)=mtinv2mt(mt*mu);
            M(k)=norm(m(:,:,k),'fro')/sqrt(2); %Scalar moment
            Mw(k)=0.67*(log10(M(k))-9.1); %Moment magnitude, 9.1 for Nm, 16.1 for dyn-cm
            L(k)=(Gj*mt-d)'*(Gj*mt-d);   %Misfit
            s=Ns+1;  %Keep track of No of synthetics produced
        else %No synthetics
            L(k)=0;
            Mo(k)=0;
            Mw(k)=0;
            synthetics(s,2)=ti(k);
            s=s+1;
        end
    end

if plotflag==1   
    clear G N E U T
    %Make plots of syntehtics
    figure
    tplot=unique(synthetics(:,2));
    for k=1:size(tplot,1)
    
        [row col]=find(synthetics(:,2)==tplot(k));
        t(k)=tplot(k);
        if synthetics(row(1),1)>0
            ista=synthetics(row,1);

            dz=synthetics(row,3);
            dx=synthetics(row,4);
            dy=synthetics(row,5);
            sz=synthetics(row,6);
            sx=synthetics(row,7);
            sy=synthetics(row,8);     


            %Get station coordinates
            xc=x(ista)/1000;
            yc=y(ista)/1000;
            
            %Plot, plot, plotaroo...
            scale=2;
            quiver(yc,xc,dy,dx,scale)
            hold on
            quiver(yc,xc,sy,sx,scale)
            xlim([-max(dsta)/1000 max(dsta)/1000]);
            ylim([-max(dsta)/1000 max(dsta)/1000]);
            axis equal
            grid on
            xlabel('East (km)','FontSize',18)
            ylabel('North (km)','FontSize',18)
            title(['t = ' num2str(t(k))],'FontSize',18);
            legend('Observed','Synthetic')
            hold off
            pause(0.01)
            

        else
            xlim([-max(dsta) max(dsta)]);
            ylim([-max(dsta) max(dsta)]);
            axis equal
            grid on
            xlabel('East (km)','FontSize',18)
            ylabel('North (km)','FontSize',18)
            title(['t = ' num2str(t(k))],'FontSize',18);
            pause(0.05)
        end
        
    end
    %Compare final verticals
%     figure
%     nx=max([size(sx,1) size(sx,2)]);
%     sx=zeros(nx,1);
%     quiver(yc,xc,sx,-dz,scale)
%     hold on
%     quiver(y,x,sx,-sz,scale)
%     xlim([-max(dsta)/1000 max(dsta)/1000]);
%     ylim([-max(dsta)/1000 max(dsta)/1000]);
%     axis equal
%     grid on
%     xlabel('East (km)','FontSize',18)
%     ylabel('North (km)','FontSize',18)
%     title(['t = ' num2str(t(k))],'FontSize',18);
%     legend('Observed','Synthetic')
%     hold off
%     a=0;
    
end
%==========================================    
%Output for movie
display('Creating flat files for movie...')
clear S
ts=unique(synthetics(:,2));    
scale=0.15;   %25cm dispalcement is one inch on plot
%Count max no. of stations
nsta=size(unique(synthetics(:,1)),1)-1;
S=zeros(nsta,size(ts,1)*4);  %Observed data goes here
Ss=zeros(nsta,size(ts,1)*4); %Synthetics go here
for k=0:size(ts,1)-1
   is=find(synthetics(:,2)==ts(k+1));
   ista=synthetics(is,1);
   nsta=size(ista,1);
   if ista>0 %if there is data to be saved
        degd=km2deg(dsta(ista)/1000);   %Convert km to degrees
        azi=rad2deg(az(ista));   %Azimuth to degrees for dead reckoning
        [S(1:nsta,2+4*k) S(1:nsta,1+4*k)]=reckon(late,lone,degd,azi); %Station coords.
        Ss(1:nsta,1+4*k)=S(1:nsta,1+4*k);  %ditto...
        Ss(1:nsta,2+4*k)=S(1:nsta,2+4*k);
        S(1:nsta,3+4*k)=rad2deg(atan2(synthetics(is,4),synthetics(is,5)));  %Coseismic azimuth (from East!!!)
        S(1:nsta,4+4*k)=sqrt(synthetics(is,5).^2+synthetics(is,4).^2)/scale;  %Coseismic amplitude
        Ss(1:nsta,3+4*k)=rad2deg(atan2(synthetics(is,7),synthetics(is,8)));  %Coseismic azimuth, synthetic
        Ss(1:nsta,4+4*k)=sqrt(synthetics(is,8).^2+synthetics(is,4).^2)/scale; %Coseismic amplitude, synthetic
   end    %Otherwise keep zeros

end
%Make time vector for GMT plots
ts=ts-(origin-correction);
cd /diego-local/scripts/GMT/fastCMT
%Sendai
% S=S(:,5:8);
% Ss=Ss(:,5:8);
%
save('coseis.obs','S','-ascii');
save('coseis.syn','Ss','-ascii');
fid = fopen('coseis.time', 'w');
fprintf(fid, '%3i\n', ts);
fclose(fid);
fid = fopen('Mw.dat', 'w');
fprintf(fid, '%1.2f\n', Mw);
fclose(fid);
%depth=L; %To color code according to misfit
make_psmeca(m*1e7,lone,late,depth)
%M=mcart2mrp(Ms);
%make_psmeca(M*1e7,late,lone,depth)   %Saving in dyn-cm
%