function makestafile(x,y,N)

cd /Users/dmelgarm/Documents/scripts/Fortran/SyntheticGPS
x=linspace(-x,x,N);
y=linspace(-y,y,N);
[X Y]=meshgrid(x,y);
save('xsta.dat','X','-ascii');
save('ysta.dat','Y','-ascii');