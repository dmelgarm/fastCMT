function R=multirotmat(az,direction);

%DMM 04/2011
%
%EDGRN code outptus Green functions in a local cilindircal frame, here we
%build a rotation matrix from local cilindircal to local cartesian given a
%source-station azimuth (from north).
%The matrix is built in blocs of 3x3 where each block has it's own azimuth
%corresponding to one station-event pair.

%direction -  1 is convert from z,r,theta to z,x,y
%             2 is convert from z,x,y to z,r,theta

nsource=size(az,1);
ndata=size(az,2);
R=zeros(nsource*3,ndata*3);
if direction==1
    for kd=1:ndata
        for ks=1:nsource
            azi=az(ks,kd);
            r=[1 0 0;0 cos(azi) -sin(azi);0 sin(azi) cos(azi)];
            i=3*(ks-1)+1;
            j=3*(kd-1)+1;
            R(i:i+2,j:j+2)=r;
        end
    end
else
    for kd=1:ndata
        for ks=1:nsource
            azi=az(ks,kd);
            r=[1 0 0;0 cos(azi) sin(azi);0 -sin(azi) cos(azi)];
            i=3*(ks-1)+1;
            j=3*(kd-1)+1;
            R(i:i+2,j:j+2)=r;
        end
    end
end