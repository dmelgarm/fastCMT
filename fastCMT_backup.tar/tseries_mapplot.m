function tseries_mapplot(f,mu,epi,normflag,weightflag,plotflag)

%Define epicentre or centroid
%Origin (GCMT seems to be the best)
late = epi(2);
lone = epi(1);
depth=28e3;

%Get station info
% El Mayor
% cd /diego-local/Research/Events/GPS
% [n e r]=get_init_pos('SEM_coseis_AZRYfix.txt',late,lone);
% Sendai
%cd /Users/dmelgarm/Desktop/Sendai
%[n e r]=get_init_pos('jpl_offsets.dat',late,lone);
%toki
cd /diego-local/Research//Data/GEONET/
[sta X Y Z a a a a a a]=textread('toki_init','%f%f%f%f%f%f%f%f%f%f');
[lat,lon,alt] = ecef2lla(X,Y,Z);
lat=rad2deg(lat);
lon=rad2deg(lon);
[dist,az] = distance(late,lone,lat,lon);
dist=deg2km(dist)*1000;
az=-az+90;
az=deg2rad(az);
[e n]=pol2cart(az,dist);
x=n;
y=e;

%USE PRE_SAVED DATA
%cd /diego-local/Research/Events/GPS
%cd /Users/dmelgarm/Desktop/Sendai/
cd /diego-local/Research/Data/GEONET/
%load GFs.mat
%dsta=r;
dsta=dist;
az=atan2(y,x);

%El Mayor
%load d_MA120.mat
% %load d.mat
%
%Sendai
%cd /Users/dmelgarm/Desktop/Sendai/
%load sendai_jpl.mat
%
%TOKI
load toki.mat
N=N';
E=E';
U=U';
T=T'-T(1,1);

%stafil=[13 27 33 46 60 61 62 63 64 65 66 67 69 70 71 72 77 81];  %Stations i know have good looking offsets
%stafil=(1:1:1216);  %Sendai
stafil=(1:1:415); %TOKI
i=find(dsta<1500e3);   %Filter by desired range
stafil=find(ismember(i,stafil));   %Good offsets within those stations in range
%Synth
% stafil=1:1:Nsynth;
% dsta=r;
% %


%First extract data in range (counter i) then extract interesting stations
%(counter stafil)
% T=T(:,i);
% nt=size(T,1);
% az=az(i);
% dsta=dsta(i);
% x=x(i);
% y=y(i);
% E=E(:,i);
% N=N(:,i);
% U=U(:,i);
% az=az(stafil);
% dsta=dsta(stafil);
% x=x(stafil);
% y=y(stafil);
% T=T(:,stafil);
% E=E(:,stafil);
% N=N(:,stafil);
% U=U(:,stafil);
% nsta=size(T,2);
%Toki
nsta=size(T,2);
nt=size(T,1);

%Not for Sendai
%mE=mean(E(1:500,:));
mE=mean(E(1:5,:));
mN=mean(N(1:5,:));
mU=mean(U(1:5,:));
mE=repmat(mE,nt,1);
mN=repmat(mN,nt,1);
mU=repmat(mU,nt,1);
E=E-mE;
N=N-mN;
U=(U-mU);
%Reduce times
ti=1:1:550;
%origin=660; %EQ origin time
origin=T(1,1)+23;
correction=0; %Correction for MA
nt=size(T,1);
[rc c]=find(T>=ti(1) & T<=ti(end));

%Make Gram amtrix
%G=prepinv(f,x,y,late,lone,depth); %El mayor


% %synth
% ti=1;
% %


% %Filter
% fc=0.01;
% forder=4;
% N=fbutter(N,1,forder,fc,'low');
% E=fbutter(E,1,forder,fc,'low');
% U=fbutter(U,1,forder,fc,'low');
% %

%Normalize
S=eye(nsta*3);
if normflag==1
    S=sqrt(E(rc(1):rc(end),:).^2+N(rc(1):rc(end),:).^2+U(rc(1):rc(end),:).^2);
    S=max(S);
    S=repmat(S,nt,1);
    ES=E./S;
    NS=N./S;
    US=U./S;
end

%Obtain measurememnt errors from 500 seconds of pre-event data
ystd=std(E(1:5,:));
xstd=std(N(1:5,:));
zstd=std(U(1:5,:))*5;

%Make indices to extract GFs from remaining stations
% i1=stafil*3-2;
% i2=stafil*3-1;
% i3=stafil*3;
% j1=interleave(i1,i2);
% j2=interleave(i2,i3);
% j=unique(interleave(j1,j2));
% G=G(j,:);  %Retain only remaining GFs



%Iterate through epochs
nt=size(ti,2);
m=zeros(3,3,nt); %Moment tensor
ds=zeros(size(stafil,1)*3,1); %Normalized data vector
thresh=0.0;  %Observation threshold
synthetics=zeros(size(dsta,1),8);  %Synthetics stored here
s=1;  %Synthetics matrix counter


    %synth
%     for k=1
    
tplot=0:1:414
figure
for k=1:415
    i=find(~isnan(T(k,:)));
    n(k)=size(i,2);
    quiver(y(i)',x(i)',E(k,i),N(k,i));
    axis equal
    grid on
    xlabel('Longitude','FontSize',18)
    ylabel('Latitude','FontSize',18)
    title(['t = ' num2str(T(k,1))],'FontSize',18);
    legend('Observed','Synthetic')
    hold off
    pause(0.01)
    clear i
end
figure
plot(n)
a=0;

