[m11 m22 m33 m12 m13 m23]=function fastCMT(d)

%Loop each second is in here


[G d]=prepinv(f)