[m L synthetics]=mfastCMT(coseis,f,velmod,epi,psmecaf,weightflag,plotflag,Ln)

%DMM 06/2011
%
% Invert for moment tensor each time sample using GPS data. Inversion is
% performed using the coseismic offsets with a Green's function approach.
% Green's functions are obtained from EDGRN numerical code (Wang et al.,
% 2003).
%
% Coordinate system throughout this code and the functions called within is
% (X,Y,Z)=(North,East,Down), this is important, save yourself headaches and 
% remember this fact.
%
% Input variables:
%
% coseis - Structure variable containing the following fields
%     .N ~ North dispalcement;
%     .E ~ East dispalcement;
%     .U ~ Vertical dispalcement;
%     .T ~ Time, zero is assumed to be the event origin time;
%     .lon ~ Station longitudes;
%     .lat ~ Station latitudes;
%     .stdn ~ Uncertainties in north observations (pre-event std. deviaiton);
%     .stde ~ Uncertainties in east observations;
%     .stdu ~ Uncertainties in vertical observations;
% f - Green function file
% velmod - Four column strucure model, column 1 is depth of layer, column 2
%          is p-wave velocity, column 3 is s wave velocity, column 4 is density
% epi - epicenter [lon lat depth(m)]
% psmecaf - psmeca filename
% weightflag - Weight by preevent standard deviations on all 3 channels.
% plotflag - Plot observed andsynthetic offsets each time sample.
%
% Output variables:
%
% m - 3x3xNt array containing the moment tensor at each time step.
% L - 1xNt array containing misfits at each time step.
% synthetics - Observed and synthetic displacements
%_______________________________________________________________________
%_______________________________________________________________________

tic

%Define coordinate origin
late = epi(2);
lone = epi(1);
depth= epi(3);

%Assign data
N=coseis.N';
E=coseis.E';
U=-coseis.U';
T=coseis.T';
stdn=coseis.stdn;
stde=coseis.stde;
stdu=coseis.stdu;
lat=coseis.lat;
lon=coseis.lon;

%Get station info
[dist,az] = distance(late,lone,lat,lon);
dist=deg2km(dist)*1000;
az=-az+90;
az=deg2rad(az);
[e n]=pol2cart(az,dist);
x=n;
y=e;
dsta=dist;
az=atan2(y,x);

%Dimensions of data
nt=size(T,1);
nsta=size(T,2);
ti=1:1:nt;

%Initalize stuff
m=zeros(3,3,nt); %Moment tensor
synthetics=zeros(size(dsta,1),8);  %Synthetics stored here
s=1;  %Synthetics matrix counter
thresh=0.0  %Observation threshold

%MAKE KERNEL MATRIX __________________
[GZ1 GR1 GT1 GZ2 GR2 GT2 GZ3 GR3 GZ4 GR4 GT4 GZ5 GR5 GT5] =makegreen(f,x,y,depth);

%Prepare inversion matrices
display('Preparing matrices for inversion...')
k=1;
for i=1:size(GR1,1)
    %Vertical component of Gram matrix
    G(k,1)=GZ1(i);
    G(k,2)=GZ2(i);
    G(k,3)=GZ3(i);
    G(k,4)=GZ4(i);
    G(k,5)=GZ5(i);
    %Radial component of Gram matrix
    G(k+1,1)=GR1(i);
    G(k+1,2)=GR2(i);
    G(k+1,3)=GR3(i);
    G(k+1,4)=GR4(i);
    G(k+1,5)=GR5(i);
    %Tangential component of Gram matrix
    G(k+2,1)=GT1(i);
    G(k+2,2)=GT2(i);
    G(k+2,3)=0;
    G(k+2,4)=GT4(i);
    G(k+2,5)=GT5(i);
    k=k+3;
end
% __________________________________



% MAIN PROGRAM _____________________
display('Inverting single CMT...')
mu=getmu(velmod,depth)
for k=1:nt
    if k==200
        a=0;
    end
    Tcurrent=T(k,:);
    i=find(~isnan(Tcurrent));
    Ecurrent=E(k,:);
    Ncurrent=N(k,:);
    Ucurrent=U(k,:);
    %Use only stations over threshold
    horiz=sqrt(Ecurrent.^2+Ncurrent.^2);
    i=find(horiz>=thresh);
    nsta=max([size(i,1) size(i,2)]);  %Stations in this epoch
    %Noise matrix
    W=eye(nsta*3);
    if nsta>2
        %Prepare data vector
        ds=zeros(nsta*3,1);
        dx=Ncurrent(i);
        dy=Ecurrent(i);      %Un-normalized for moment
        dz=Ucurrent(i);
        azi=az(i);
        d=ones(size(i,1)*3,1);
        iinv=1:1:nsta*3;
        iinv=reshape(iinv,3,nsta);
        %Indices for preparing d vector
        i1=iinv(1,:);
        i2=iinv(2,:);
        i3=iinv(3,:);
        %Extract only relevant rows of Gram matrix
        ii1=i*3-2;
        ii2=i*3-1;
        ii3=i*3;
        j1=interleave(ii1,ii2);
        j2=interleave(ii2,ii3);
        j=unique(interleave(j1,j2));
        Gj=G(j,:);
        %Assemble into column vector
        d(i1)=dz;
        d(i2)=dx;
        d(i3)=dy;
        %Rotate un-normalized data to z,r,theta
        rot=buildrotmat(azi,2);
        d=rot*d;
        %Weight by standard errors
        if weightflag==1
            %Simplified weight scheme
            dw=zeros(1,nsta*3);
%             dw(i1)=1/5;
%             dw(i2)=1;
%             dw(i3)=1;
            dw(i1)=1./stdu; %z
            dw(i2)=1./stdn; %x
            dw(i3)=1./stde; %y
            W=diag(dw);
            is=isnan(W);
            W(is)=0;
            d=W*d;
            Gj=W*Gj;  %Weigh GFs by same factor as data
        end
        

        if Ln==2   %L2
            mt=lsqlin(Gj,d);
        elseif Ln==1   %L1
            m0=ones(5,1)*1e17/mu;
            mt = l1decode_pd(m0, Gj, [], d);
        else
            display('FATAL ERROR, no norm selected, must select norm=1 for L1 or norm=2 for L2, terminating execution.')
            return
        end
        % _____________

%         Synthetic mt
%         mt=[0.777 1.32 2.59;1.32 -0.411 -0.662;2.560090 -0.662 -0.366]*1e21/mu;
%         mt=[1.82 1.34 3.17;1.34 -0.13 -0.56;3.17 -0.56 -1.69]*(1e22/mu);
%          mt=[-0.249 -0.056 -0.014; -0.056 -0.594 -0.089;-0.014 -0.086 0.843]*(1e20)/mu;
%          mt=mrp2mcart(mt);
%          mt=mt2mtinv(mt);
%         _____
        
        %Rescale for synthetics
        if weightflag==1
            Gj=W\Gj;
            d=W\d;
        end
        %Compute misfits
        if Ln==1 
            L(k)=sum(abs((Gj*mt-d)))/sum(abs(d));
        else
            L(k)=((Gj*mt-d)'*(Gj*mt-d))/(d'*d);
        end
      
        %Synthetics
        dsynth=Gj*mt;
        %Rotate back to z,x,y
        rot=buildrotmat(azi,1);
        dsynth=rot*dsynth;
        d=rot*d;
        %Misfit
        %;%Misfit
        %             dx=d(i2)-dsynth(i2);
        %             dy=d(i3)-dsynth(i3);
        %             xrms=sqrt(sum(dx.^2)/nsta);600
        %             yrms=sqrt(sum(dy.^2)/nsta);
        %             L(k)=sqrt(xrms^2+yrms^2);
        
        %             % synthetics %%% TESTING ONLY
        %             st=345;
        %             dip=45;
        %             rake=45;
        %             Mo=7.28e19/3.77e10;
        %             Ms=sdr2mom(st,dip,rake)*Mo;
        %             ms=mt2mtinv(Ms);
        %             dsynth=Gjs*ms;
        %             mt=lsqlin(Gjs,dsynth);
        %             rot=buildrotmat(azi,1);
        %             dsynth=rot*dsynth;
        %
        %
        %             %%%%%%%%%%%%%
        
        %Construct synthetics
        %1=station, 2=time, 3,4,5=observed data (Z,X,Y), 6,7,8=inverted
        %data, 9,10, station coords
        Ns=s+nsta-1;
        synthetics(s:Ns,1)=i;
        synthetics(s:Ns,2)=ti(k);
        synthetics(s:Ns,3)=d(iinv(1,:));
        synthetics(s:Ns,4)=d(iinv(2,:));
        synthetics(s:Ns,5)=d(iinv(3,:));
        synthetics(s:Ns,6)=dsynth(iinv(1,:));
        synthetics(s:Ns,7)=dsynth(iinv(2,:));
        synthetics(s:Ns,8)=dsynth(iinv(3,:));
        synthetics(s:Ns,9)=lon(i);
        synthetics(s:Ns,10)=lat(i);
        %Scale moment tensor by mu and write in cartesian form
        m(:,:,k)=mtinv2mt(mt*mu);
        M(k)=norm(m(:,:,k),'fro')/sqrt(2); %Scalar moment
        Mw(k)=0.67*(log10(M(k))-9.1); %Moment magnitude, 9.1 for Nm, 16.1 for dyn-cm
        s=Ns+1;  %Keep track of No of synthetics produced
    else %No synthetics
        L(k)=0;
        Mo(k)=0;
        Mw(k)=0;
        synthetics(s,2)=ti(k);
        s=s+1;
    end
end

if plotflag==1
    clear G N E U T
    %Make plots of syntehtics
    figure
    tplot=unique(synthetics(:,2));
    for k=1:size(tplot,1)
        
        [row col]=find(synthetics(:,2)==tplot(k));
        t(k)=tplot(k);
        if synthetics(row(1),1)>0
            ista=synthetics(row,1);
            
            dz=synthetics(row,3);
            dx=synthetics(row,4);
            dy=synthetics(row,5);
            sz=synthetics(row,6);
            sx=synthetics(row,7);
            sy=synthetics(row,8);
            
            
            %Get station coordinates
            xc=x(ista)/1000;
            yc=y(ista)/1000;
            
            %Plot, plot, plotaroo...
            scale=1.5;
            subplot(1,2,1)   %Horizontals
            quiver(yc,xc,dy,dx,scale)
            hold on
            quiver(yc,xc,sy,sx,scale)
            %Plot limits
            limx=[min(yc) max(yc)];
            dlimx=(limx(2)-limx(1))*0.1;
            limx(1)=limx(1)-dlimx;
            limx(2)=limx(2)+dlimx;
            limy=[min(xc) max(xc)];
            dlimy=(limy(2)-limy(1))*0.1;
            limy(1)=limy(1)-dlimy;
            limy(2)=limy(2)+dlimy;
            
            xlim(limx);
            ylim(limy);
            axis equal
            grid on
            xlabel('East (km)','FontSize',18)
            ylabel('North (km)','FontSize',18)
            title(['t = ' num2str(t(k))],'FontSize',18);
            legend('Observed','Synthetic')
            hold off
            subplot(1,2,2)   %verticals
            pq=zeros(size(xc));
            quiver(yc,xc,pq,dz,scale)
            hold on
            quiver(yc+5,xc,pq,sz,scale)
            
            xlim(limx);
            ylim(limy);
            axis equal
            grid on
            xlabel('East (km)','FontSize',18)
            ylabel('North (km)','FontSize',18)
            title(['t = ' num2str(t(k))],'FontSize',18);
            legend('Observed','Synthetic')
            hold off
            
            pause(0.01)
            
            
        else
            subplot(1,2,1)
            xlim([min(xc) max(xc)]);
            ylim([min(yc) max(yc)]);
            axis equal
            grid on
            xlabel('East (km)','FontSize',18)
            ylabel('North (km)','FontSize',18)
            title(['t = ' num2str(t(k))],'FontSize',18);
            subplot(1,2,2)
            xlim([min(xc)/1000 max(xc)/1000]);
            ylim([min(yc)/1000 max(yc)/1000]);
            axis equal
            grid on
            xlabel('East (km)','FontSize',18)
            ylabel('North (km)','FontSize',18)
            title(['t = ' num2str(t(k))],'FontSize',18);
            pause(0.01)
        end
    end
end
toc