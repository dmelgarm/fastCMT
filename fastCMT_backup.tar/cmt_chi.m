function cmt_chi

