function [n e d]=get_init_pos(init_pos,late,lone)

%Written by B.Crowell, commented and tweaked by D.Melgar circa 2010
%
%Read station Inital positions and desired epicentral location (or centroid
%location) and output (x,y) pairs for each station-epicentre pair on a grid
%centered at the epicentre. This output will be used to mine the GFs
%
%IN
%
%init_pos - Station data filename
%late - event latitude
%lone - event longitude
%
%OUT
%
%[n e d] - station north(n) and east (e) coordiantes and source-event
%          distance along a great circle path




cd('/diego-local/Research/Events/GPS');
%cd('/Users/dmelgarm/Desktop/Sendai');
%Read initial positions
%El Mayor
[lon,lat,east,north,up,site]=textread(init_pos, '%f %f %f %f %f %s');
%Sendai
%[lon,lat,east,north,up,a,a]=textread(init_pos, '%f %f %f %f %f %f %s');
% load('sendai_jpl.mat')
% lon=lonsta;
% lat=latsta;
% 
% i1=find(lat<45.5 & lat>32);
% i2=find(lon<143 & lon >130);
% j=intersect(i1,i2);
% lon=lon(j);
% lat=lat(j);
%
I=ones(size(lon,1),1);
%Get radial distances from epicentre to stations
d=hvrd(lat,I*late,lon,I*lone);
%Get azimuth from source to station (can use function atan2 here as well)
a = 6378137;
e = 8.1819190842622e-2;
ellipsoid=[a e];
az = azimuth('gc',I*late,I*lone,lat,lon);
%Convert to x,y
az=-az+90;
az=deg2rad(az);
[e n]=pol2cart(az,d);
